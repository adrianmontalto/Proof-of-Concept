﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

    //attach this script to player

    public float score;
    public float points;

    // Use this for initialization
    void Start () 
    {
        score = 0;
    }
	
	// Update is called once per frame
	void Update () 
    {
        //shows score for debugging puropses
        Debug.Log("points:" + points);

        //if right mouse clicked
        if (Input.GetMouseButtonDown(1) && points >= 1)
		{
            //raycasts at mouse postion
			RaycastHit hit;
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            //if raycast hits
			if (Physics.Raycast(ray, out hit))
		    {        
                //create light at clicked position
                GameObject Light =
                Instantiate(Resources.Load("SpawnLight"),
                hit.point,
                Quaternion.identity) as GameObject;

				Light.transform.rotation = Quaternion.Euler (90, 0, 0);

                //take away points to spend
                points -= 1;

                }
			}
		}
	}









