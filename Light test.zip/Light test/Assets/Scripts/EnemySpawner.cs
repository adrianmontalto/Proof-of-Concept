﻿using UnityEngine;
using System.Collections;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemy_prefab;
    public GameObject spawner;

    public float spawn_time;
    public float randomMax;
    public float randomMin;
    public float waveAmount;
    public float waveIncreaseAmount;
    public float waveWaitingTime;

    private Player player;
    private float spawn_timer;
    private float waveWaitingTimer;
    private float searchCountdown;
    private int enemyCount;
    private bool waiting = false;
    private bool spawning = true;

	// Use this for initialization
	void Start ()
    {
        spawn_timer = spawn_time;
        waveWaitingTimer = waveWaitingTime;
        player = GameObject.FindObjectOfType<Player>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        if(spawning == true)
        {
            if(enemyCount < waveAmount)
            {
                Spawning();
            }
                        
            if(EnemyIsAlive() == false)
            {
                spawning = false;
                waveAmount += waveIncreaseAmount;
                waiting = true;
            }
        }
	}

    void Spawning()
    {
        //count down the timer every frame
        spawn_timer -= Time.deltaTime;

        //checks to see if it is time to spawn
        if (spawn_timer < 0)
        {
            //reset the timer
            spawn_timer = spawn_time;

            //we want spawn at random position
            float spawnY = Random.Range(randomMin, randomMax);

            //find final point to the enemy
            Vector3 spawn_point = new Vector3(spawner.transform.position.x, spawner.transform.position.y, spawnY);

            //actually spawn the enemy
            Instantiate(enemy_prefab, spawn_point, Quaternion.identity);

            //increase enemy count
			enemyCount ++;
        }
    }

    bool EnemyIsAlive()
    {
        searchCountdown -= Time.deltaTime;
        if (searchCountdown <= 0f)
        {

            searchCountdown = 1f;
            if (GameObject.FindGameObjectsWithTag("Enemy") == null)
            {
                return false;
            }
        }

        return true;
    }

    void Waiting()
    {
        waveWaitingTimer -= Time.deltaTime;
        if(waveWaitingTimer < 0)
        {
            waiting = false;
            waveWaitingTimer = waveWaitingTime;
            spawning = true;
        }
    }
}
