﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour
{
	//attach this script to enemy

	private Player player;
	public float speed;



	// Use this for initialization
	void Start ()
	{
		//finds player gameobject
		player = GameObject.FindObjectOfType<Player>();
	}

	// Update is called once per frame
	void Update()
	{

		//makes the enemy chase the player
		Vector3 vector_to_player = player.transform.position - this.transform.position;
		vector_to_player.Normalize();
		this.transform.position = this.transform.position + vector_to_player * speed * Time.deltaTime;
		this.transform.rotation = Quaternion.LookRotation(vector_to_player);
	}

}
