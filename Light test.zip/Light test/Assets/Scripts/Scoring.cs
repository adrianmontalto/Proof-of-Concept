﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Scoring : MonoBehaviour
{
    public float score = 0;

    [SerializeField]
    GameObject textbox;

    void OnTriggerEnter(Collider scoreAdd)
    {
        if (scoreAdd.CompareTag("Enemy"))
        {
            //when the player collides with the scoreblock, add 1 score
            score = score + 1.0f;
            //the score will be set as the string
            textbox.GetComponent<Text>().text = score.ToString();
        }
    }
}
