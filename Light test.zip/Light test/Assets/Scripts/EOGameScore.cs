﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class EOGScore : MonoBehaviour
{

    void Start()
    {
        GetComponent<Text>().text = PlayerPrefs.GetFloat("score").ToString();
    }

}
