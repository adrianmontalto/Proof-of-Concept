﻿using UnityEngine;
using System.Collections;

public class CollsionManagerScript : MonoBehaviour {

    //Please attach this script to an empty , thanks :)
    //ps make sure that the ground has a box collider as well
    public float speed;
    private Player player;

    




	// Use this for initialization
	void Start () {

    //find player gameobject
    player = GameObject.FindObjectOfType<Player>();

	}
	
	// Update is called once per frame
	void Update () {


        //gets mouse click
		if (Input.GetMouseButton(0))
		{
            //raycasts at mouse position
			RaycastHit hit;
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);


            //if raycasting
			if (Physics.Raycast(ray, out hit))
			{
                //gets box collider
				BoxCollider bc = hit.collider as BoxCollider;
				if (bc != null)
				{
                    //if it enemy tagged object destroy and give player points and score
                    if (hit.collider.tag == "Enemy")
                    {
                        //add a point for the enemy killed
                        player.score += 1;

                        //add one fifth of the necesary points for the player to spawn a light
                        player.points += 0.2f;

                        //destroy the enemy
                        Destroy(bc.gameObject);

                    }
                }
			}
		}
	}


	
}
